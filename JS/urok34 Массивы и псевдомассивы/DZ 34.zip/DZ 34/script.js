
//    DZ
// №1) Преобразуйте псевдо массив  в массив
    // дан псевдо массив  {0: 'first', 1: 'second', 2: 'third', length: 3} 
    // вывод [ "first", "second", "third" ]

        let object = {0: 'first', 1: 'second', 2: 'third', length: 3};
        let array = [];

        for (let i = 0; i < object.length; i++) {
            array.push(object[i]);
            console.log(object[i]);
        }
        console.log(array);





    

    